### dataframe for RLSSM packages

import os
import pandas as pd

# remove outlier file based on the costom_peg_value
exclude_list = [9, 13, 14, 32, 34, 43]
list=[]
data_list = []
cnt = 0
n_data = 2
folder = os.getcwd()
folder = os.path.join(folder, 'study3_data')
df = pd.DataFrame

def is_excluded(filename):
    try:
        file_idx = int(filename.split('_')[0])
    except:
        print('%s is not data file' % filename)
        return True

    for item in exclude_list:
        if file_idx == item:
            print('%s is excluded' % filename)
            return True
    return False

def load_CSV(subject_folder):
    data_list = os.listdir(subject_folder)
    for item in data_list:
        if item.find('BDG_financial_2021_') == 0:
            fin_file = os.path.join(subject_folder, item)
            BDG_finan = pd.read_csv(fin_file)
            pass
        elif item.find('BDG_pegturning_2021_') == 0:
            peg_file = os.path.join(subject_folder, item)
            BDG_peg = pd.read_csv(peg_file)
            pass

# def create_new_dataframe(BDG_finan, BDG_peg):




for filename in os.listdir(folder):
    cnt = cnt + 1
    if is_excluded(filename):
        continue    
    
    list.append(filename)
    subject_folder = os.path.join(folder, filename)
    load_CSV(subject_folder)
    # for  items in n_data:
    #     create_new_dataframe(BDG_finan, BDG_peg)

        
print(list)


# load csv 


# data extract and reframe
# participant, blcok_label, trial_block, f_cor, f_inc, cor_option, int_option, times_seen, rt, accuracy

# save csv
